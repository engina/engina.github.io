% Load the continous signal
signal = load('ecg_hfn.dat');

% Template size. This will extract the first
% (t_size * 1/F) seconds of the signal.
t_size = 86;

% Starting point of the template sample
t_start = 250;
% Extract the template from sample
tpl = signal( t_start:t_start+t_size-1 );

% Now iterate through the original signal
% Whenever you see a high match value, that's a beat

% The lower the threshold, the more matches you'll get.
threshold = 0.80;

% Size of the original signal
[h w] = size( signal );

% The signal that we'll put marks where we find the beats
peaks = zeros(h,1);

% Beat counter
counter = 0;

% Search index
index = -1;

% The previous location the beat is found
prev = -1;

% Longest beat sample length
longest = 0;

% The result, as each beat is in a row
result = [];

for i = 0:h-t_size-1
    % Increment index by one in each iteration
    index = index + 1;
    if( template_match( signal, tpl, index ) > threshold )
        % A match which exceeds threshold, this should be a beat
        counter = counter + 1;
        if( prev ~= -1 )
           % If there is a previous beat point found, copy the interval
           % between that point and this one as one sample beat.
           if( (index-prev) > longest )
               % This beat sample is longer than any other previous one
               current_length = index - prev + 1;
               % 0-Pad right side of the matrix so the length is OK
               % for this signal
               result(:,current_length) = 0;
               % Update longest signal length
               longest = current_length;
               % Copy the interval
               result(counter,:) = signal(prev:index);
           else
               % The interval is shorter than one of the previous signals
               % We should 0-pad the right side of it and than copy to a
               % new row
               [s_h s_w] = size(signal(prev:index));
               result(counter,:) = [signal(prev:index); zeros(longest-s_h,1)];
           end
        end
        % Update the prev
        prev = index;
        % We found a beat, skip this reagon. Because in this area we'll get
        % many points that exceeds threhold
        index = index + t_size/2;
        % Mark the peak in peaks signal so that we can visuals it if we
        % want
        peaks(index+1) = signal(index+1);
    end
end

% Plot one of the original beats
plot(result(2,:),'g');
hold on;
% Average the syncronized beats
avg = averagev(result);
% Plot the obtained signal by synchronized averaging
plot(avg);