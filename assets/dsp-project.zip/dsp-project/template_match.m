function r = template_match( signal, template, index )
% Returns template match value of a template
% on a signal at a certain index

% text book notation
y = signal;
x = template;
k = index;
[t_h t_w] = size( x );
N = t_h;

[s_h s_w] = size( y );
if( k+1+N < s_h )
y_avg = averagev( signal(k+1:k+1+N) );
x_avg = averagev( template );
top = 0;
bottom_left = 0;
bottom_right = 0;
for n = 0:N-2
    top = top + ( x(n+1)-x_avg )*( y( abs(n - k) + 1 ) - y_avg );
    bottom_left = bottom_left + ( x(n+1) - x_avg )^2;
    bottom_right = bottom_right + ( y( abs(n - k) + 1 ) - y_avg  )^2;
end
r = top / sqrt( bottom_left * bottom_right );
else
r = 0;
end