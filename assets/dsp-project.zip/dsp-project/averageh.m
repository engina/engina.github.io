function r = averageh( signals )
% Computes avarage of a set of sample signals.
% Each column is a sample.
% This function will apply a sum() on signals
% then divide the resulting matrix by the column
% count.

[h w] = size(signals);
r = sum(signals)/w;